Non-existent page: https://people.rit.edu/dsg6874/230/error/

Error directory: https://people.rit.edu/dsg6874/230/error/

Auth page: https://people.rit.edu/dsg6874/230/auth
